﻿using System.Text;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static System.Net.Mime.MediaTypeNames;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private Dictionary<string, string> randomMessages = new Dictionary<string, string>();
        private Random random = new Random();

        private void GenerateRandomMessage(string key, string message1, string message2)
        {
            if (!randomMessages.ContainsKey(key))
            {
                int randomNumber = random.Next(2);

                randomMessages[key] = (randomNumber == 0) ? message1 : message2;
            }

            MessageBox.Show(randomMessages[key]);
        }

        private void MotherboardClick(object sender, RoutedEventArgs e)
        {
            if (Motherboard.Visibility == Visibility.Visible || Back.Visibility == Visibility.Visible)
            {
                Motherboard.Visibility = Visibility.Hidden;
                Bios.Visibility = Visibility.Hidden;
                Scheme.Visibility = Visibility.Visible;
                Back.Visibility = Visibility.Hidden;
            }
            else
            {
                Motherboard.Visibility = Visibility.Visible;
                Bios.Visibility = Visibility.Visible;
                Scheme.Visibility = Visibility.Hidden;
            }
        }

        private void BackMother(object sender, RoutedEventArgs e)
        {
            if (Motherboard.Visibility == Visibility.Visible || Scheme.Visibility == Visibility.Visible)
            {
                Motherboard.Visibility = Visibility.Hidden;
                Bios.Visibility = Visibility.Hidden;
                Back.Visibility = Visibility.Visible;
                Scheme.Visibility = Visibility.Hidden;
            }
            else
            {
                Motherboard.Visibility = Visibility.Visible;
                Bios.Visibility = Visibility.Visible;
                Back.Visibility = Visibility.Hidden;
            }
        }
        private void Battery(object sender, RoutedEventArgs e)
        {
            if (Motherboard.Visibility != Visibility.Visible)
            {
                return;
            }

            if (!GND.IsChecked.Value)
            {
                MessageBox.Show("Ошибка: Не выбран GND");
                return;
            }

            ComboBoxItem selectedMode = (ComboBoxItem)MeasurementMode.SelectedItem;
            if (selectedMode == null)
            {
                MessageBox.Show("Ошибка: Не выбран режим измерения");
                return;
            }
            if (selectedMode.Content.ToString() == "Измерение напряжения")
            {
                GenerateRandomMessage("Battery", "3.024 V", "0V");
            }
        }

        private void V1(object sender, RoutedEventArgs e)
        {
            if (Motherboard.Visibility != Visibility.Visible)
            {
                return;
            }

            if (!GND.IsChecked.Value)
            {
                MessageBox.Show("Ошибка: Не выбран GND");
                return;
            }

            ComboBoxItem selectedMode = (ComboBoxItem)MeasurementMode.SelectedItem;
            if (selectedMode == null)
            {
                MessageBox.Show("Ошибка: Не выбран режим измерения");
                return;
            }
            if (selectedMode.Content.ToString() == "Измерение сопротивления")
            {
                GenerateRandomMessage("V1", "1.5971 КОм", "Кз");
            }
        }
        private void V2(object sender, RoutedEventArgs e)
        {
            if (Motherboard.Visibility != Visibility.Visible)
            {
                return;
            }

            if (!GND.IsChecked.Value)
            {
                MessageBox.Show("Ошибка: Не выбран GND");
                return;
            }

            ComboBoxItem selectedMode = (ComboBoxItem)MeasurementMode.SelectedItem;
            if (selectedMode == null)
            {
                MessageBox.Show("Ошибка: Не выбран режим измерения");
                return;
            }
            if (selectedMode.Content.ToString() == "Измерение сопротивления")
            {
                GenerateRandomMessage("V2", "0.7521 КОм", "Кз");
            }
        }

        private void V3(object sender, RoutedEventArgs e)
        {
            if (Motherboard.Visibility != Visibility.Visible)
            {
                return;
            }

            if (!GND.IsChecked.Value)
            {
                MessageBox.Show("Ошибка: Не выбран GND");
                return;
            }

            ComboBoxItem selectedMode = (ComboBoxItem)MeasurementMode.SelectedItem;
            if (selectedMode == null)
            {
                MessageBox.Show("Ошибка: Не выбран режим измерения");
                return;
            }
            if (selectedMode.Content.ToString() == "Измерение сопротивления")
            {
                MessageBox.Show("0.5425 КОм");
            }
        }

        private void V4(object sender, RoutedEventArgs e)
        {
            if (Motherboard.Visibility != Visibility.Visible)
            {
                return;
            }

            if (!GND.IsChecked.Value)
            {
                MessageBox.Show("Ошибка: Не выбран GND");
                return;
            }

            ComboBoxItem selectedMode = (ComboBoxItem)MeasurementMode.SelectedItem;
            if (selectedMode == null)
            {
                MessageBox.Show("Ошибка: Не выбран режим измерения");
                return;
            }
            if (selectedMode.Content.ToString() == "Измерение сопротивления")
            {
                GenerateRandomMessage("V4", "6.3148 КОм", "0.0245 КОм");
            }
        }

        private void USB1(object sender, RoutedEventArgs e)
        {
            if (Back.Visibility != Visibility.Visible)
            {
                return;
            }

            if (!GND.IsChecked.Value)
            {
                MessageBox.Show("Ошибка: Не выбран GND");
                return;
            }

            ComboBoxItem selectedMode = (ComboBoxItem)MeasurementMode.SelectedItem;
            if (selectedMode == null)
            {
                MessageBox.Show("Ошибка: Не выбран режим измерения");
                return;
            }
            if (selectedMode.Content.ToString() == "Измерение напряжения")
            {
                MessageBox.Show("0.5247 мВ");
            }
        }
        private void USB2(object sender, RoutedEventArgs e)
        {
            if (Back.Visibility != Visibility.Visible)
            {
                return;
            }

            if (!GND.IsChecked.Value)
            {
                MessageBox.Show("Ошибка: Не выбран GND");
                return;
            }

            ComboBoxItem selectedMode = (ComboBoxItem)MeasurementMode.SelectedItem;
            if (selectedMode == null)
            {
                MessageBox.Show("Ошибка: Не выбран режим измерения");
                return;
            }
            if (selectedMode.Content.ToString() == "Измерение напряжения")
            {
                MessageBox.Show("0.5235 мВ");
            }
        }
        private void USB3(object sender, RoutedEventArgs e)
        {
            if (Back.Visibility != Visibility.Visible)
            {
                return;
            }

            if (!GND.IsChecked.Value)
            {
                MessageBox.Show("Ошибка: Не выбран GND");
                return;
            }

            ComboBoxItem selectedMode = (ComboBoxItem)MeasurementMode.SelectedItem;
            if (selectedMode == null)
            {
                MessageBox.Show("Ошибка: Не выбран режим измерения");
                return;
            }
            if (selectedMode.Content.ToString() == "Измерение напряжения")
            {
                MessageBox.Show("0.5254 мВ");
            }
        }
        private void USB4(object sender, RoutedEventArgs e)
        {
            if (Back.Visibility != Visibility.Visible)
            {
                return;
            }

            if (!GND.IsChecked.Value)
            {
                MessageBox.Show("Ошибка: Не выбран GND");
                return;
            }

            ComboBoxItem selectedMode = (ComboBoxItem)MeasurementMode.SelectedItem;
            if (selectedMode == null)
            {
                MessageBox.Show("Ошибка: Не выбран режим измерения");
                return;
            }
            if (selectedMode.Content.ToString() == "Измерение напряжения")
            {
                MessageBox.Show("0.5244 мВ");
            }
        }
        private void USB5(object sender, RoutedEventArgs e)
        {
            if (Back.Visibility != Visibility.Visible)
            {
                return;
            }

            if (!GND.IsChecked.Value)
            {
                MessageBox.Show("Ошибка: Не выбран GND");
                return;
            }

            ComboBoxItem selectedMode = (ComboBoxItem)MeasurementMode.SelectedItem;
            if (selectedMode == null)
            {
                MessageBox.Show("Ошибка: Не выбран режим измерения");
                return;
            }
            if (selectedMode.Content.ToString() == "Измерение напряжения")
            {
                MessageBox.Show("0.5245 мВ");
            }
        }

        private void USB6(object sender, RoutedEventArgs e)
        {
            if (Back.Visibility != Visibility.Visible)
            {
                return;
            }

            if (!GND.IsChecked.Value)
            {
                MessageBox.Show("Ошибка: Не выбран GND");
                return;
            }

            ComboBoxItem selectedMode = (ComboBoxItem)MeasurementMode.SelectedItem;
            if (selectedMode == null)
            {
                MessageBox.Show("Ошибка: Не выбран режим измерения");
                return;
            }
            if (selectedMode.Content.ToString() == "Измерение напряжения")
            {
                MessageBox.Show("0.5242 мВ");
            }
        }

        private void USB7(object sender, RoutedEventArgs e)
        {
            if (Back.Visibility != Visibility.Visible)
            {
                return;
            }

            if (!GND.IsChecked.Value)
            {
                MessageBox.Show("Ошибка: Не выбран GND");
                return;
            }

            ComboBoxItem selectedMode = (ComboBoxItem)MeasurementMode.SelectedItem;
            if (selectedMode == null)
            {
                MessageBox.Show("Ошибка: Не выбран режим измерения");
                return;
            }
            if (selectedMode.Content.ToString() == "Измерение напряжения")
            {
                GenerateRandomMessage("USB", "0.5250 мВ", "0 мВ");
            }
        }
        private void USB8(object sender, RoutedEventArgs e)
        {
            if (Back.Visibility != Visibility.Visible)
            {
                return;
            }

            if (!GND.IsChecked.Value)
            {
                MessageBox.Show("Ошибка: Не выбран GND");
                return;
            }

            ComboBoxItem selectedMode = (ComboBoxItem)MeasurementMode.SelectedItem;
            if (selectedMode == null)
            {
                MessageBox.Show("Ошибка: Не выбран режим измерения");
                return;
            }
            if (selectedMode.Content.ToString() == "Измерение напряжения")
            {
                MessageBox.Show("0.5243 мВ");
            }
        }
        private void USB9(object sender, RoutedEventArgs e)
        {
            if (Back.Visibility != Visibility.Visible)
            {
                return;
            }

            if (!GND.IsChecked.Value)
            {
                MessageBox.Show("Ошибка: Не выбран GND");
                return;
            }

            ComboBoxItem selectedMode = (ComboBoxItem)MeasurementMode.SelectedItem;
            if (selectedMode == null)
            {
                MessageBox.Show("Ошибка: Не выбран режим измерения");
                return;
            }
            if (selectedMode.Content.ToString() == "Измерение напряжения")
            {
                MessageBox.Show("0.5249 мВ");
            }
        }

        private void USB10(object sender, RoutedEventArgs e)
        {
            if (Motherboard.Visibility != Visibility.Visible)
            {
                return;
            }
            if (!GND.IsChecked.Value)
            {
                MessageBox.Show("Ошибка: Не выбран GND");
                return;
            }

            ComboBoxItem selectedMode = (ComboBoxItem)MeasurementMode.SelectedItem;
            if (selectedMode == null)
            {
                MessageBox.Show("Ошибка: Не выбран режим измерения");
                return;
            }
            if (selectedMode.Content.ToString() == "Измерение напряжения")
            {
                MessageBox.Show("0.5252 мВ");
            }
        }
        private void USB11(object sender, RoutedEventArgs e)
        {
            if (Motherboard.Visibility != Visibility.Visible)
            {
                return;
            }
            if (!GND.IsChecked.Value)
            {
                MessageBox.Show("Ошибка: Не выбран GND");
                return;
            }

            ComboBoxItem selectedMode = (ComboBoxItem)MeasurementMode.SelectedItem;
            if (selectedMode == null)
            {
                MessageBox.Show("Ошибка: Не выбран режим измерения");
                return;
            }
            if (selectedMode.Content.ToString() == "Измерение напряжения")
            {
                MessageBox.Show("0.5240 мВ");
            }
        }
        private void USB12(object sender, RoutedEventArgs e)
        {
            if (Motherboard.Visibility != Visibility.Visible)
            {
                return;
            }
            if (!GND.IsChecked.Value)
            {
                MessageBox.Show("Ошибка: Не выбран GND");
                return;
            }

            ComboBoxItem selectedMode = (ComboBoxItem)MeasurementMode.SelectedItem;
            if (selectedMode == null)
            {
                MessageBox.Show("Ошибка: Не выбран режим измерения");
                return;
            }
            if (selectedMode.Content.ToString() == "Измерение напряжения")
            {
                GenerateRandomMessage("USB", "0.5238 мВ", "0 мВ");
            }
        }
        private void USB13(object sender, RoutedEventArgs e)
        {
            if (Motherboard.Visibility != Visibility.Visible)
            {
                return;
            }

            if (!GND.IsChecked.Value)
            {
                MessageBox.Show("Ошибка: Не выбран GND");
                return;
            }

            ComboBoxItem selectedMode = (ComboBoxItem)MeasurementMode.SelectedItem;
            if (selectedMode == null)
            {
                MessageBox.Show("Ошибка: Не выбран режим измерения");
                return;
            }
            if (selectedMode.Content.ToString() == "Измерение напряжения")
            {
                MessageBox.Show("0.5241 мВ");
            }
        }

        private void Kwartz(object sender, RoutedEventArgs e)
        {
            if (Motherboard.Visibility != Visibility.Visible)
            {
                return;
            }

            if (!GND.IsChecked.Value)
            {
                MessageBox.Show("Ошибка: Не выбран GND");
                return;
            }

            ComboBoxItem selectedMode = (ComboBoxItem)MeasurementMode.SelectedItem;
            if (selectedMode == null)
            {
                MessageBox.Show("Ошибка: Не выбран режим измерения");
                return;
            }
            if (selectedMode.Content.ToString() == "Осциллограф")
            {
                Window1 oscilWindow = new Window1();
                oscilWindow.Show();
            }
        }

        private void USB14(object sender, RoutedEventArgs e)
        {
            if (Motherboard.Visibility != Visibility.Visible)
            {
                return;
            }

            if (!GND.IsChecked.Value)
            {
                MessageBox.Show("Ошибка: Не выбран GND");
                return;
            }

            ComboBoxItem selectedMode = (ComboBoxItem)MeasurementMode.SelectedItem;
            if (selectedMode == null)
            {
                MessageBox.Show("Ошибка: Не выбран режим измерения");
                return;
            }
            if (selectedMode.Content.ToString() == "Измерение напряжения")
            {
                MessageBox.Show("0.5247 мВ");
            }
        }
        private void USB15(object sender, RoutedEventArgs e)
        {
            if (Motherboard.Visibility != Visibility.Visible)
            {
                return;
            }

            if (!GND.IsChecked.Value)
            {
                MessageBox.Show("Ошибка: Не выбран GND");
                return;
            }

            ComboBoxItem selectedMode = (ComboBoxItem)MeasurementMode.SelectedItem;
            if (selectedMode == null)
            {
                MessageBox.Show("Ошибка: Не выбран режим измерения");
                return;
            }
            if (selectedMode.Content.ToString() == "Измерение напряжения")
            {
                MessageBox.Show("0.5239 мВ");
            }
        }
        private void USB16(object sender, RoutedEventArgs e)
        {
            if (Motherboard.Visibility != Visibility.Visible)
            {
                return;
            }

            if (!GND.IsChecked.Value)
            {
                MessageBox.Show("Ошибка: Не выбран GND");
                return;
            }

            ComboBoxItem selectedMode = (ComboBoxItem)MeasurementMode.SelectedItem;
            if (selectedMode == null)
            {
                MessageBox.Show("Ошибка: Не выбран режим измерения");
                return;
            }
            if (selectedMode.Content.ToString() == "Измерение напряжения")
            {
                MessageBox.Show("0.5244 мВ");
            }
        }
        private void USB17(object sender, RoutedEventArgs e)
        {
            if (Motherboard.Visibility != Visibility.Visible)
            {
                return;
            }

            if (!GND.IsChecked.Value)
            {
                MessageBox.Show("Ошибка: Не выбран GND");
                return;
            }

            ComboBoxItem selectedMode = (ComboBoxItem)MeasurementMode.SelectedItem;
            if (selectedMode == null)
            {
                MessageBox.Show("Ошибка: Не выбран режим измерения");
                return;
            }
            if (selectedMode.Content.ToString() == "Измерение напряжения")
            {
                GenerateRandomMessage("USB", "0.5255 мВ", "0 мВ");
            }
        }

        private void Bios1(object sender, RoutedEventArgs e)
        {
            if (Motherboard.Visibility != Visibility.Visible)
            {
                return;
            }

            if (!GND.IsChecked.Value)
            {
                MessageBox.Show("Ошибка: Не выбран GND");
                return;
            }

            ComboBoxItem selectedMode = (ComboBoxItem)MeasurementMode.SelectedItem;
            if (selectedMode == null)
            {
                MessageBox.Show("Ошибка: Не выбран режим измерения");
                return;
            }
            if (selectedMode.Content.ToString() == "Осциллограф")
            {
                GenerateRandomMessage("Bios1", "Сигналы(импульсы) присутствуют", "Сигналы(импульсы) отсутствуют");
            }
        }

        private void Bios2(object sender, RoutedEventArgs e)
        {
            if (Motherboard.Visibility != Visibility.Visible)
            {
                return;
            }

            if (!GND.IsChecked.Value)
            {
                MessageBox.Show("Ошибка: Не выбран GND");
                return;
            }

            ComboBoxItem selectedMode = (ComboBoxItem)MeasurementMode.SelectedItem;
            if (selectedMode == null)
            {
                MessageBox.Show("Ошибка: Не выбран режим измерения");
                return;
            }
            if (selectedMode.Content.ToString() == "Осциллограф")
            {
                GenerateRandomMessage("Bios2", "Сигналы(импульсы) присутствуют", "Сигналы(импульсы) отсутствуют");
            }
        }
        private void Videocard1(object sender, RoutedEventArgs e)
        {
            if (Motherboard.Visibility != Visibility.Visible)
            {
                return;
            }

            ComboBoxItem selectedMode = (ComboBoxItem)MeasurementMode.SelectedItem;
            if (selectedMode == null)
            {
                MessageBox.Show("Ошибка: Не выбран режим измерения");
                return;
            }

            if (selectedMode.Content.ToString() == "Тестер")
            {
                GenerateRandomMessage("Videocard1", "Горят все лампочки", "Горят не все лампочки");
            }
        }

        private void Videocard2(object sender, RoutedEventArgs e)
        {
            if (Motherboard.Visibility != Visibility.Visible)
            {
                return;
            }


            ComboBoxItem selectedMode = (ComboBoxItem)MeasurementMode.SelectedItem;
            if (selectedMode == null)
            {
                MessageBox.Show("Ошибка: Не выбран режим измерения");
                return;
            }
            if (selectedMode.Content.ToString() == "Тестер")
            {
                GenerateRandomMessage("Videocard2", "Горят все лампочки", "Горят не все лампочки");
            }
        }
        private void Drossel(object sender, RoutedEventArgs e)
        {
            if (Motherboard.Visibility != Visibility.Visible)
            {
                return;
            }

            if (!GND.IsChecked.Value)
            {
                MessageBox.Show("Ошибка: Не выбран GND");
                return;
            }



            ComboBoxItem selectedMode = (ComboBoxItem)MeasurementMode.SelectedItem;
            if (selectedMode == null)
            {
                MessageBox.Show("Ошибка: Не выбран режим измерения");
                return;
            }
            if (selectedMode.Content.ToString() == "Измерение сопротивления")
            {
                GenerateRandomMessage("Drossel", "3.6 Ом", "0 Ом");
            }
        }

        private void DDR41(object sender, RoutedEventArgs e)
        {
            if (Motherboard.Visibility != Visibility.Visible)
            {
                return;
            }


            ComboBoxItem selectedMode = (ComboBoxItem)MeasurementMode.SelectedItem;
            if (selectedMode == null)
            {
                MessageBox.Show("Ошибка: Не выбран режим измерения");
                return;
            }
            if (selectedMode.Content.ToString() == "Тестер")
            {
                GenerateRandomMessage("DDR4", "Все лампочки горят", "Горят не все лампочки");
            }
        }

        private void DDR42(object sender, RoutedEventArgs e)
        {
            if (Motherboard.Visibility != Visibility.Visible)
            {
                return;
            }


            ComboBoxItem selectedMode = (ComboBoxItem)MeasurementMode.SelectedItem;
            if (selectedMode == null)
            {
                MessageBox.Show("Ошибка: Не выбран режим измерения");
                return;
            }
            if (selectedMode.Content.ToString() == "Тестер")
            {
                GenerateRandomMessage("DDR42", "Все лампочки горят", "Горят не все лампочки");
            }
        }

        private void DDR43(object sender, RoutedEventArgs e)
        {
            if (Motherboard.Visibility != Visibility.Visible)
            {
                return;
            }

            ComboBoxItem selectedMode = (ComboBoxItem)MeasurementMode.SelectedItem;
            if (selectedMode == null)
            {
                MessageBox.Show("Ошибка: Не выбран режим измерения");
                return;
            }
            if (selectedMode.Content.ToString() == "Тестер")
            {
                GenerateRandomMessage("DDR4", "Все лампочки горят", "Горят не все лампочки");
            }
        }

        private void DDR44(object sender, RoutedEventArgs e)
        {
            if (Motherboard.Visibility != Visibility.Visible)
            {
                return;
            }


            ComboBoxItem selectedMode = (ComboBoxItem)MeasurementMode.SelectedItem;
            if (selectedMode == null)
            {
                MessageBox.Show("Ошибка: Не выбран режим измерения");
                return;
            }
            if (selectedMode.Content.ToString() == "Тестер")
            {
                GenerateRandomMessage("DDR4", "Все лампочки горят", "Горят не все лампочки");
            }
        }

        private void CPU(object sender, RoutedEventArgs e)
        {
            if (Motherboard.Visibility != Visibility.Visible)
            {
                return;
            }


            ComboBoxItem selectedMode = (ComboBoxItem)MeasurementMode.SelectedItem;
            if (selectedMode == null)
            {
                MessageBox.Show("Ошибка: Не выбран режим измерения");
                return;
            }
            if (selectedMode.Content.ToString() == "Тестер")
            {
                GenerateRandomMessage("CPU", "Все лампочки горят", "Горят не все лампочки");
            }
        }

        private void Panel1(object sender, RoutedEventArgs e)
        {
            if (Motherboard.Visibility != Visibility.Visible)
            {
                return;
            }

            if (!GND.IsChecked.Value)
            {
                MessageBox.Show("Ошибка: Не выбран GND");
                return;
            }

            ComboBoxItem selectedMode = (ComboBoxItem)MeasurementMode.SelectedItem;
            if (selectedMode == null)
            {
                MessageBox.Show("Ошибка: Не выбран режим измерения");
                return;
            }
            if (selectedMode.Content.ToString() == "Измерение напряжения")
            {
                GenerateRandomMessage("Panel", "3.3 V", "0 V");
            }
        }

        private void Panel2(object sender, RoutedEventArgs e)
        {
            if (Motherboard.Visibility != Visibility.Visible)
            {
                return;
            }

            if (!GND.IsChecked.Value)
            {
                MessageBox.Show("Ошибка: Не выбран GND");
                return;
            }

            ComboBoxItem selectedMode = (ComboBoxItem)MeasurementMode.SelectedItem;
            if (selectedMode == null)
            {
                MessageBox.Show("Ошибка: Не выбран режим измерения");
                return;
            }
            if (selectedMode.Content.ToString() == "Измерение напряжения")
            {
                GenerateRandomMessage("Panel", "3.3 V", "0 V");
            }
        }

    }
}